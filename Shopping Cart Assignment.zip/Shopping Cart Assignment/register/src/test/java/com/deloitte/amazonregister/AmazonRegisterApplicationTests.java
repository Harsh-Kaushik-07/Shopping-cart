package com.deloitte.amazonregister;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
