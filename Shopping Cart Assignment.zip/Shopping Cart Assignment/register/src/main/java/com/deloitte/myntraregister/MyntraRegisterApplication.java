package com.deloitte.myntraregister;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyntraRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyntraRegisterApplication.class, args);
	}

}
